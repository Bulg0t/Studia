#ifndef CSITO1_H
#define CSITO1_H


class cSito1
{
    public:
        cSito1(int);
        virtual ~cSito1();
        void Odsiej();
        void Wyswietl();
        bool Sprawdz(int);
    protected:

    private:
        int mN;
        int mTab[];
};

#endif // CSITO1_H
