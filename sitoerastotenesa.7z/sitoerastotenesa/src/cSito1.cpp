#include "cSito1.h"
#include<iostream>
using namespace std;
cSito1::cSito1(int aN)
{
    mN=aN;
    int mTab[mN+1];
    mTab[0]=mTab[1]=1;
    for(int i =2; i<=mN; i++)
    {
        mTab[i]=i;

    }
    //ctor
}

void cSito1::Odsiej(){

    for(int i=2;i<=mN;i++)
    {
            for(int j =i+i; j<=mN;j+=i)
            {
                mTab[j]=-1;
            }
        if(mTab[i]>0)
        {
                cout << mTab[i] << " ";
                //icznik ++;

        }
    }
}

void cSito1::Wyswietl(){
    for(int i=2;i<=mN;i++)
    {
                if(mTab[i]>0)
        {
                cout << i << " ";
                //licznik ++;

        }
    }   //cout << "Ilosc liczb pierwszych: " << licznik << endl;
}

cSito1::~cSito1()
{
    //dtor
}
