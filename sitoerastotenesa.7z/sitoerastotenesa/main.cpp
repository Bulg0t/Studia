#include <iostream>
#include "cSito1.h"

using namespace std;

int main()
{
    int n,p,licznik;
    cout << "Podaj liczbe N: " << endl;
    cin >> n;
    //cSito1 sito1(n);
    //sito1.Wyswietl();
    //sito1.Odsiej();
    //sito1.Wyswietl();
    int tablica[n-1];
    for(int i =2; i<=n; i++)
    {
        tablica[i]=i;

    }

    for(int i=2;i<=n;i++)
    {
            for(int j =i+i; j<=n;j+=i)
            {
                tablica[j]=-1;
            }
        if(tablica[i]>0)
        {
                cout << tablica[i] << " ";
                licznik ++;

        }
    }
    cout << endl;
    cout << "Ilosc liczb pierwszych: " << licznik << endl;


    return 0;
}
