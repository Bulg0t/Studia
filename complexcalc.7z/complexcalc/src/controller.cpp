#include "controller.h"
#include "cWidok.h"
#include "zespolona.h"

controller::controller()
{
    //ctor
}

controller::~controller()
{
    //dtor
}

controller::controller(cZespolona *m, cWidok *w)
{
this->m = m;
this->w = w;
this->w->add(this); // podanie kontrolera do widoku
}
