#include "cWidok.h"

cWidok::cWidok()
{
    //ctor
}

cWidok::~cWidok()
{
    //dtor
}

void cWidok::pokaz()
{
    if(c->m->zIm >0 )
    {
            std::cout << c->m->zRe << " + " << c->m->zIm << "i" << std::endl;

    }
    else if(c->m->zIm == 0){
        std::cout << c->m->zRe << std::endl;
    }
    else{
               std::cout << c->m->zRe << " - " << (-1)*c->m->zIm << "i" << std::endl;
    }

}
void cWidok::tryg()
{
    std::cout << c->m->modul() << "[cos(" << c->m->argument() << ")" << "+ i*sin(" << c->m->argument() << ")]" << std::endl;
}

void cWidok::wykladnicza()
{
    std:: cout << c->m->modul() << "*e^("  << c->m->argument() << "*i"<< ")" << std::endl;
}


//interakcja widoku z kontrolerem
void cWidok::add(controller *c)
{
    this->c = c;
}

