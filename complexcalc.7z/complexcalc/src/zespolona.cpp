#include "zespolona.h"
#include <math.h>
#include <cmath>
#include <complex>
cZespolona::cZespolona()
{
    //ctor
}

cZespolona::cZespolona(double mRe, double mIm)
{
    zRe=mRe;
    zIm=mIm;
}

cZespolona::~cZespolona()
{
    //dtor
}

void cZespolona::wczytaj()
{
    std::cout << "Podaj czesc rzeczywista: " << std::endl;
    std::cin >> (*this).zRe;
    std::cout << "Podaj czesc urojona: " << std::endl;
    std::cin >> (*this).zIm;

}
cZespolona cZespolona::operator+(cZespolona &z)
{
    cZespolona tmp;
    tmp.zRe =  zRe + z.zRe;

    tmp.zIm = zIm + z.zIm;
    return tmp;
}

cZespolona cZespolona::operator-(cZespolona &z)
{
    cZespolona tmp;
    tmp.zRe =  zRe - z.zRe;

    tmp.zIm = zIm - z.zIm;
    return tmp;
}

cZespolona cZespolona::operator*(cZespolona &z)
{
    cZespolona tmp;
    tmp.zRe = zRe * z.zRe + (-1)*zIm*z.zIm;
    tmp.zIm = zRe*z.zIm + z.zRe*zIm;
    return tmp;
}

cZespolona cZespolona::operator,(cZespolona &z)
{
    cZespolona tmp;
    tmp.zRe = (zRe * z.zRe + zIm * z.zIm);
    tmp.zIm = (-1)*(zRe*z.zIm + z.zRe*(-1)*zIm);
    tmp.zRe = tmp.zRe/(z.zRe*z.zRe + z.zIm*z.zIm);
    tmp.zIm = tmp.zIm/(z.zRe*z.zRe + z.zIm*z.zIm);
    return tmp;
}

double cZespolona::modul()
{
    cZespolona r;
    r.zRe = sqrt(pow(zRe,2)+pow(zIm,2));
    r.zIm = 0;
    return r.zRe;
}

double cZespolona::argument()
{
    if(zRe>0)
    {
        return atan(zIm/zRe);
    }
    else if (zRe < 0){
        return (atan(zIm/zRe) + M_PI);
    }
    else if (zRe == 0)
    {


        if(zIm > 0)
        {
            return 0.5*M_PI;
        }
        if(zIm<0)
        {
            return -0.5*M_PI;
        }
    }
    }




cZespolona cZespolona::potega()
{
    int n;
    std::cout << "Podaj wykladnik potegi: ";
    std::cin >> n;
    cZespolona tmp;
    std::complex<double> z1((*this).zRe, (*this).zIm); // tworz� zmienn� complex o typie danych double, w celu podniesienia jej do pot�gi
    std::complex<double> z2;
    z2 = pow(z1, n);
    tmp.zRe = real(z2);
    tmp.zIm = imag(z2);
    return tmp;

}
cZespolona cZespolona::pierwiastek()
{
    cZespolona tmp;
    std::complex<double> z1((*this).zRe, (*this).zIm);
    std::complex<double> z2;
    //z2 = pow(z1,(1/double(n)));
    z2 = sqrt(z1); //argument sie zgadza z oczekiwanym, tmp.argument() =/= arg(z2) nwm czemu
    tmp.zRe = real(z2);
    tmp.zIm = imag(z2);
    return tmp;
}

