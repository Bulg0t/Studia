#include <iostream>
#include "zespolona.h"
#include "cWidok.h"
#include "controller.h"
#include <conio.h>

using namespace std;

int menu() //view wyswietla menu, i wyniki dzialan
{ //controller wczytuje liczby do programu i przesyla do modelu
    // model oblicza wynik danego dzialania i przesyla do widoku
   cWidok *view = new cWidok();
   cWidok *view1 = new cWidok();
   cWidok *view2 = new cWidok();
   cZespolona *model = new cZespolona();
   cZespolona *model1 = new cZespolona();
   cZespolona *model2 = new cZespolona();
   controller *c = new controller(model, view);
   controller *c1 = new controller(model1, view1);
   controller *c2 = new controller(model2, view2);

    int n;
    do{
    cout<<"*********Kalkulator liczb zespolonych**********\n" << endl;
    cout<<"1. Wczytaj liczbe zespolona;"<<endl;
    cout<<"2. Wyswietl liczbe zespolona" << endl;
    cout<<"3. Dodaj liczby zespolone"<<endl;
    cout<<"4. Odejmij liczby zespolone"<<endl;
    cout<<"5. Pomnoz liczby zespolone"<<endl;
    cout<<"6. Podziel liczby zespolone"<<endl;
    cout<<"7. Poteguj liczbe zespolona"<<endl;
    cout<<"8. Pierwiastkuj liczbe zespolona"<<endl;
    cout<<"9. Modul liczby zespolonej"<<endl;
    cout<<"10. Argument liczby zespolonej"<<endl;
    cout<<"11. Postac wykladnicza liczby zespolonej"<<endl;
    cout<<"12. Postac trygonometryczna liczby zespolonej"<<endl;
    cout<<"13. Zakoncz program"<<endl;
    cin >> n;
    cout << endl;
    switch(n){
case 1:
    cout << "Podaj wartosci: " << endl;
    c->m->wczytaj();
    c1->m->wczytaj();
    break;
case 2:
    cout << "Liczby zespolone: " << endl;
    c->w->pokaz();
    c1->w->pokaz();
    break;
case 3:
    *(c2->m)=*(c->m)+*(c1->m);
    cout << "Suma podanych liczb zespolonych wynosi: " << endl;
    c2->w->pokaz();
    break;
case 4:
    *(c2->m)=*(c->m)-*(c1->m);
    cout << "Roznica podanych liczb zespolonych wynosi: " << endl;
    c2->w->pokaz();
    break;
case 5:
    *(c2->m)=*(c->m)**(c1->m);
    cout << "Iloczyn podanych liczb zespolonych wynosi: " << endl;
    c2->w->pokaz();
    break;
case 6:
    *(c2->m)=*(c->m),*(c1->m);
    cout << "Iloraz podanych liczb zespolonych wynosi: " << endl;
    c2->w->pokaz();
    break;
case 7:
    cout << "Potega n-tego stopnia 1-wszej liczby zespolonej: " << endl;
    *(c2->m) = c->m->potega();
    c2->w->pokaz();
    cout << "Potega n-tego stopnia 2-giej liczby zespolonej: " << endl;
    *(c2->m) = c1->m->potega();
    c2->w->pokaz();
    break;
case 8:
    cout << "Pierwiastek kwadratowy 1-wszej liczby zespolonej: " << endl;
    *(c2->m) = c->m->pierwiastek();
    c2->w->pokaz();
    cout << "Pierwiastek kwadratowy 2-giej liczby zespolonej: " << endl;
    *(c2->m) = c1->m->pierwiastek();
    c2->w->pokaz();
    break;
case 9:
    cout << "Modul 1-wszej liczby zespolonej: "<<endl;
    cout << c->m->modul() << endl;
    cout << "Modul 2-giej liczby zespolonej: "<<endl;
    cout << c1->m->modul() << endl;
    break;
case 10:
    cout << "Argument 1-wszej liczby zespolonej: "<<endl;
    c->w->pokaz();
    cout << c->m->argument()<<endl;
    cout << "Argument 2-giej liczby zespolonej: " << endl;
    c1->w->pokaz();
    cout << c1->m->argument()<<endl;
    break;
case 11:
    cout << "Postac wykladnicza 1-wszej liczby zespolonej: " << endl;
    c->w->wykladnicza();
    cout << "Postac wykladnicza 2-giej liczby zespolonej: " << endl;
    c1->w->wykladnicza();
    break;
case 12:
    cout << "Postac trygonometryczna 1-wszej liczby zespolonej: " << endl;
    c->w->tryg();
    cout << "Postac trygonometryczna 2-giej liczby zespolonej: " << endl;
    c1->w->tryg();
    break;
case 13:
    return 1;
    break;
default:
    cout << "Bledne polecenie! "<<endl;
    break;

    }
    }while(1);


}

int main()
{
   // menu();

   //model->wczytaj();
   //view->pokaz();
   //view->tryg();
   menu();
    return 0;
}
