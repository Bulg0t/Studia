#include "controller.h"
#ifndef CWIDOK_H
#define CWIDOK_H
#include <iostream>
class controller;
class cWidok
{
    public:
        cWidok();
        virtual ~cWidok();
        void pokaz();
        void tryg();
        void add(controller*);
        void wykladnicza();
        controller *c;

    protected:
    private:
};

#endif // CWIDOK_H
