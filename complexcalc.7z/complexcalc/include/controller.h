#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "zespolona.h"
#include "cWidok.h"
#include <iostream>
class cWidok;
class cZespolona;
class controller
{
    public:
        cZespolona *m;
        cWidok *w;
        controller();
        virtual ~controller();
        void wczytaj();
        controller(cZespolona *, cWidok *);

    protected:
    private:
};

#endif // CONTROLLER_H
