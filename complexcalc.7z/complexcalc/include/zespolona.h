#ifndef ZESPOLONA_H
#define ZESPOLONA_H
#include <iostream>

class cZespolona
{
    public:
        cZespolona();
        cZespolona(double, double);
        virtual ~cZespolona();
        void wczytaj();//
        cZespolona operator +(cZespolona &);
        cZespolona operator -(cZespolona &);
        cZespolona operator *(cZespolona &);
        cZespolona operator ,(cZespolona &);
        double modul();
        double argument();
        void wykladnicza();//
        cZespolona potega(void);
        cZespolona pierwiastek(void);
        double zRe;
        double zIm;
    protected:

    private:
};

#endif // ZESPOLONA_H
