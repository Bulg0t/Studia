#include <iostream>
#include "cMainController.h"
#include "cLiczbaZespolona.h"
#include "cMainView.h"
#include "cMainModel.h"

using namespace std;
/*
1-- dodawanie
2-- odejmowanie
3--mnozenie
4--dzielenie
5--modul 1
6--modul 2
7--argument 1
8--argument 2
9--potega 1
10--potega 2
11--pierwiastek kwadratowy 1
12--pierwiastek kwadratowy 2
*/
int main()
{
    cMainController kontroler;
    kontroler.mModel->setliczba1(kontroler.wczytaj1());
    kontroler.mModel->setliczba2(kontroler.wczytaj2());
    kontroler.mWidok->pokaz(kontroler.mModel->getwynik(11));
    //kontroler.mWidok->tryg(kontroler.mModel->getliczba1());
    //kontroler.mWidok->tryg(kontroler.mModel->getliczba2());

}
