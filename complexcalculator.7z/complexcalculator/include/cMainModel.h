#ifndef CMAINMODEL_H
#define CMAINMODEL_H
#include "cLiczbaZespolona.h"

class cMainController;

class cMainModel
{
    public:
        cMainModel(cMainController*);
        virtual ~cMainModel();
        void setliczba1(cLiczbaZespolona);
        void setliczba2(cLiczbaZespolona);
        cLiczbaZespolona getwynik(int);
        double wykonaj(int);
        cLiczbaZespolona getliczba1();
        cLiczbaZespolona getliczba2();


    protected:

    private:
        cMainController *mKontroler;
        cLiczbaZespolona liczba1;
        cLiczbaZespolona liczba2;
        cLiczbaZespolona wynik;
};

#endif // CMAINMODEL_H
