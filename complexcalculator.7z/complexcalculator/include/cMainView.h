#ifndef CMAINVIEW_H
#define CMAINVIEW_H
#include "cLiczbaZespolona.h"

class cMainController;

class cMainView
{
    public:
        cMainView(cMainController*);
        virtual ~cMainView();
        void wczytaj();
        void pokaz(cLiczbaZespolona);
        void tryg(cLiczbaZespolona);
        void wykladnicza(cLiczbaZespolona);

    protected:

    private:
        cMainController *mKontroler;
};

#endif // CMAINVIEW_H
