#ifndef cMainController_H
#define cMainController_H
#include "cLiczbaZespolona.h"
#include "cMainView.h"
#include "cMainModel.h"
#include <iostream>
class cMainView;
class cMainModel;
class cMainController
{
    public:

        cMainController();
        virtual ~cMainController();
        cMainController(cMainModel *, cMainView *);
        cLiczbaZespolona wczytaj1();
        cLiczbaZespolona wczytaj2();
        cMainView *mWidok;
        cMainModel *mModel;

    protected:
    private:
};

#endif // cMainController_H
