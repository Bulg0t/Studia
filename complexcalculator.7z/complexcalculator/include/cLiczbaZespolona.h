#ifndef CLICZBAZESPOLONA_H
#define CLICZBAZESPOLONA_H


class cLiczbaZespolona
{
    public:
        cLiczbaZespolona();
        cLiczbaZespolona(double, double);
        virtual ~cLiczbaZespolona();
        cLiczbaZespolona operator +(cLiczbaZespolona &);
        cLiczbaZespolona operator -(cLiczbaZespolona &);
        cLiczbaZespolona operator *(cLiczbaZespolona &);
        cLiczbaZespolona operator %(cLiczbaZespolona &);
        double modul();
        double argument();
        void wykladnicza();//
        cLiczbaZespolona potega(void);
        cLiczbaZespolona pierwiastek(void);
        double zRe;
        double zIm;
    protected:

    private:
};

#endif // CLICZBAZESPOLONA_H
