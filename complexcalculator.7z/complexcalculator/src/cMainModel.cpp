#include "cMainModel.h"
#include <iostream>
#include <cmath>
#include <complex>
cMainModel::cMainModel(cMainController *xKontroler)
{
    mKontroler = xKontroler;
}

cMainModel::~cMainModel()
{
    //dtor
}

void cMainModel::setliczba1(cLiczbaZespolona aLiczba)
{
    liczba1.zRe=aLiczba.zRe ;
    liczba1.zIm=aLiczba.zIm ;
}
void cMainModel::setliczba2(cLiczbaZespolona xLiczba)
{
    liczba2.zRe=xLiczba.zRe;
    liczba2.zIm=xLiczba.zIm;
}
double cMainModel::wykonaj(int x)
{
    if(x==1)
    {
    wynik.zRe = liczba1.zRe + liczba2.zRe;
    wynik.zIm = liczba1.zIm + liczba2.zIm;
    }
    if(x==2)
    {
    wynik.zRe = liczba1.zRe - liczba2.zRe;
    wynik.zIm = liczba1.zIm - liczba2.zIm;
    }
    if(x==3)
    {
    wynik.zRe = liczba1.zRe*liczba2.zRe + (-1)*liczba1.zIm*liczba2.zIm;
    wynik.zIm = liczba1.zRe*liczba2.zIm + liczba2.zRe*liczba1.zIm;
    }
    if(x==4)
    {
    wynik.zRe = (liczba1.zRe*liczba2.zRe + liczba1.zIm * liczba2.zIm);
    wynik.zIm = (-1)*(liczba1.zRe*liczba2.zIm + liczba2.zRe*(-1)*liczba1.zIm);
    wynik.zRe = wynik.zRe/(liczba2.zRe*liczba2.zRe + liczba2.zIm*liczba2.zIm);
    wynik.zIm = wynik.zIm/(liczba2.zRe*liczba2.zRe + liczba2.zIm*liczba2.zIm);
    }
    if(x==5)
    {
    wynik.zRe = sqrt(pow(liczba1.zRe,2)+pow(liczba1.zIm,2));
    wynik.zIm = 0;
    return wynik.zRe;
    }
    if(x==6)
    {
    wynik.zRe = sqrt(pow(liczba2.zRe,2)+pow(liczba2.zIm,2));
    wynik.zIm = 0;
    return wynik.zRe;
    }
    if(x==7)
    {
        if(liczba1.zRe>0)
        {
            wynik.zRe= atan(liczba1.zIm/liczba1.zRe);
            wynik.zIm = 0;
            return wynik.zRe;
        }
        else if (liczba1.zRe < 0){
            wynik.zRe = (atan(liczba1.zIm/liczba1.zRe) + M_PI);
            wynik.zIm = 0;
            return wynik.zRe;
        }
        else if (liczba1.zRe == 0)
        {


            if(liczba1.zIm > 0)
            {
                wynik.zRe = 0.5*M_PI;
                wynik.zIm = 0;
                return wynik.zRe;
            }
            if(liczba1.zIm<0)
            {
                wynik.zRe = -0.5*M_PI;
                wynik.zIm = 0;
                return wynik.zRe;
            }
        }
    }
    if(x==8)
    {
        if(liczba2.zRe>0)
        {
            wynik.zRe= atan(liczba2.zIm/liczba2.zRe);
            wynik.zIm = 0;
            return wynik.zRe;
        }
        else if (liczba2.zRe < 0){
            wynik.zRe = (atan(liczba2.zIm/liczba2.zRe) + M_PI);
            wynik.zIm = 0;
            return wynik.zRe;
        }
        else if (liczba2.zRe == 0)
        {


            if(liczba2.zIm > 0)
            {
                wynik.zRe = 0.5*M_PI;
                wynik.zIm = 0;
                return wynik.zRe;
            }
            if(liczba2.zIm<0)
            {
                wynik.zRe = -0.5*M_PI;
                wynik.zIm = 0;
                return wynik.zRe;
            }
        }
    }
    if(x==9)
    {
    std::complex<double> z1(liczba1.zRe, liczba1.zIm); // tworzê zmienn¹ complex o typie danych double, w celu podniesienia jej do potêgi
    std::complex<double> z2;
    z2 = pow(z1, 2);
    wynik.zRe = real(z2);
    wynik.zIm = imag(z2);
    }
    if(x==10)
    {
    std::complex<double> z1(liczba2.zRe, liczba2.zIm); // tworzê zmienn¹ complex o typie danych double, w celu podniesienia jej do potêgi
    std::complex<double> z2;
    z2 = pow(z1, 2);
    wynik.zRe = real(z2);
    wynik.zIm = imag(z2);
    }
    if(x==11)
    {
    std::complex<double> z1(liczba1.zRe, liczba1.zIm);
    std::complex<double> z2;
    z2 = sqrt(z1); //argument sie zgadza z oczekiwanym, tmp.argument() =/= arg(z2) nwm czemu
    wynik.zRe = real(z2);
    wynik.zIm = imag(z2);
    }
    if(x==12)
    {
    std::complex<double> z1(liczba2.zRe, liczba2.zIm);
    std::complex<double> z2;
    z2 = sqrt(z1); //argument sie zgadza z oczekiwanym, tmp.argument() =/= arg(z2) nwm czemu
    wynik.zRe = real(z2);
    wynik.zIm = imag(z2);
    }
}

/*cLiczbaZespolona cLiczbaZespolona::operator%(cLiczbaZespolona &z)
{
    cLiczbaZespolona tmp;
    tmp.zRe = (zRe * z.zRe + zIm * z.zIm);
    tmp.zIm = (-1)*(zRe*z.zIm + z.zRe*(-1)*zIm);
    tmp.zRe = tmp.zRe/(z.zRe*z.zRe + z.zIm*z.zIm);
    tmp.zIm = tmp.zIm/(z.zRe*z.zRe + z.zIm*z.zIm);
    return tmp;
}*/
cLiczbaZespolona cMainModel::getliczba1()
{
    return liczba1;
}
cLiczbaZespolona cMainModel::getliczba2()
{
    return liczba2;
}
cLiczbaZespolona cMainModel::getwynik(int x)
{
    wykonaj(x);
    return wynik;
}
