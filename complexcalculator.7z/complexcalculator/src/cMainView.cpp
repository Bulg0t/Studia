#include "cMainView.h"
#include <iostream>

cMainView::cMainView(cMainController *xKontroler)
{
    mKontroler = xKontroler;
}

cMainView::~cMainView()
{
    //dtor
}
 //kontroler, widok
//stworzyc nowy projekt metoda wykonaj(); w modelu, set liczba1(arg cLiczbaZespolona)
//set liczba2
//get wynik

void cMainView::pokaz(cLiczbaZespolona liczbax)
{
    if(liczbax.zIm >0 )
    {
            std::cout << liczbax.zRe << " + " << liczbax.zIm << "i" << std::endl;

    }
    else if(liczbax.zIm == 0){
        std::cout << liczbax.zRe << std::endl;
    }
    else{
               std::cout << liczbax.zRe << " - " << (-1)*liczbax.zIm << "i" << std::endl;
    }

}
void cMainView::tryg(cLiczbaZespolona liczbax)
{
    std::cout << liczbax.modul() << "[cos(" << liczbax.argument() << ")" << "+ i*sin(" << liczbax.argument() << ")]" << std::endl;
}

void cMainView::wykladnicza(cLiczbaZespolona liczbax)
{
    std:: cout << liczbax.modul() << "*e^("  << liczbax.argument() << "*i"<< ")" << std::endl;
}

