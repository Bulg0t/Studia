#include "cLiczbaZespolona.h"
#include <math.h>
#include <cmath>
#include <complex>
cLiczbaZespolona::cLiczbaZespolona()
{
    //ctor
}

cLiczbaZespolona::cLiczbaZespolona(double mRe, double mIm)
{
    zRe=mRe;
    zIm=mIm;
}

cLiczbaZespolona::~cLiczbaZespolona()
{
    //dtor
}

cLiczbaZespolona cLiczbaZespolona::operator+(cLiczbaZespolona &z)
{
    cLiczbaZespolona tmp;
    tmp.zRe =  zRe + z.zRe;

    tmp.zIm = zIm + z.zIm;
    return tmp;
}

cLiczbaZespolona cLiczbaZespolona::operator-(cLiczbaZespolona &z)
{
    cLiczbaZespolona tmp;
    tmp.zRe =  zRe - z.zRe;

    tmp.zIm = zIm - z.zIm;
    return tmp;
}

cLiczbaZespolona cLiczbaZespolona::operator*(cLiczbaZespolona &z)
{
    cLiczbaZespolona tmp;
    tmp.zRe = zRe * z.zRe + (-1)*zIm*z.zIm;
    tmp.zIm = zRe*z.zIm + z.zRe*zIm;
    return tmp;
}

cLiczbaZespolona cLiczbaZespolona::operator%(cLiczbaZespolona &z)
{
    cLiczbaZespolona tmp;
    tmp.zRe = (zRe * z.zRe + zIm * z.zIm);
    tmp.zIm = (-1)*(zRe*z.zIm + z.zRe*(-1)*zIm);
    tmp.zRe = tmp.zRe/(z.zRe*z.zRe + z.zIm*z.zIm);
    tmp.zIm = tmp.zIm/(z.zRe*z.zRe + z.zIm*z.zIm);
    return tmp;
}

double cLiczbaZespolona::modul()
{
    cLiczbaZespolona r;
    r.zRe = sqrt(pow(zRe,2)+pow(zIm,2));
    r.zIm = 0;
    return r.zRe;
}

double cLiczbaZespolona::argument()
{
    if(zRe>0)
    {
        return atan(zIm/zRe);
    }
    else if (zRe < 0){
        return (atan(zIm/zRe) + M_PI);
    }
    else if (zRe == 0)
    {


        if(zIm > 0)
        {
            return 0.5*M_PI;
        }
        if(zIm<0)
        {
            return -0.5*M_PI;
        }
    }
    }




cLiczbaZespolona cLiczbaZespolona::potega()
{
 //   int n;
//    std::cout << "Podaj wykladnik potegi: ";
  //  std::cin >> n;
    cLiczbaZespolona tmp;
    std::complex<double> z1((*this).zRe, (*this).zIm); // tworzê zmienn¹ complex o typie danych double, w celu podniesienia jej do potêgi
    std::complex<double> z2;
    z2 = pow(z1, 2);
    tmp.zRe = real(z2);
    tmp.zIm = imag(z2);
    return tmp;

}
cLiczbaZespolona cLiczbaZespolona::pierwiastek()
{
    cLiczbaZespolona tmp;
    std::complex<double> z1((*this).zRe, (*this).zIm);
    std::complex<double> z2;
    //z2 = pow(z1,(1/double(n)));
    z2 = sqrt(z1); //argument sie zgadza z oczekiwanym, tmp.argument() =/= arg(z2) nwm czemu
    tmp.zRe = real(z2);
    tmp.zIm = imag(z2);
    return tmp;
}

