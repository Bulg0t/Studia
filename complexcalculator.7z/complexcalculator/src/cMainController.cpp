#include "cMainController.h"

cMainController::cMainController()
{
    mModel = new cMainModel(this);
    mWidok = new cMainView(this);
}

cMainController::~cMainController()
{
    //dtor
}

cLiczbaZespolona cMainController::wczytaj1()
{
    cLiczbaZespolona liczbax;
    std::cout << "Podaj czesc rzeczywista: " << std::endl;
    std::cin >> liczbax.zRe;
    std::cout << "Podaj czesc urojona: " << std::endl;
    std::cin >> liczbax.zIm;
    mModel->setliczba1(liczbax);
    return liczbax;


//    std::cin >> mModel-;

}
cLiczbaZespolona cMainController::wczytaj2()
{
        cLiczbaZespolona liczbay;
    std::cout << "Podaj czesc rzeczywista: " << std::endl;
    std::cin >> liczbay.zRe;
    std::cout << "Podaj czesc urojona: " << std::endl;
    std::cin >> liczbay.zIm;
    mModel->setliczba2(liczbay);
    return liczbay;
}
