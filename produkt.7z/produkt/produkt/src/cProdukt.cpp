#include "cProdukt.h"
#include <iostream>
#include <iomanip>
using namespace std;
cProdukt::cProdukt()
{
lp=0;
cout << "konstruktor bez parametrow cProdukt" << endl;
}

cProdukt::cProdukt(int Nlp, string Nnazwa, double Nilosc, string Nunit, double Ncena){
    lp=Nlp;
    nazwa=Nnazwa;
    ilosc=Nilosc;
    unit=Nunit;
    cena=Ncena;
cout << "konstruktor z parametrami " << endl;
}

cProdukt::~cProdukt()
{
   cout << "destruktor cProdukt" << endl; //dtor
}

void cProdukt::Wypelnij()
{
    double vat1 = 0.23;
    cout << "Podaj nazwe produktu: " << endl;
    cin >> nazwa;
    cout << "Podaj ilosc produktow: " << endl;
    cin >> ilosc;
    cout << "Podaj jednostke miary dla produktu: "<< endl;
    cin >> unit;
    cout << "Podaj cene produktu: " << endl;
    cin >> cena;
    vat = cena*vat1;
    lp+=1;

}
void cProdukt::Pokaz()
{
    cout << "Lp: " << lp << endl;
    cout << "Nazwa produktu: " << nazwa << endl;
    cout << "Ilosc: " << ilosc << endl;
    cout << "Jednostka miary: " << unit << endl;
    cout << "Cena produktu: " <<fixed << setprecision(2) << cena << " zl" << endl;
    cout << "VAT(23%): " << fixed << setprecision(2) << vat << "zl" << endl;
}

void cProdukt::setLP(int aLP){
    if(aLP>0){
        lp=aLP;
    }
    else{
                cout << "Bledna wartosc lp: " << aLP << endl;
    }
}
int cProdukt::getLP(void)
{
    return(lp);
}
