#include <iostream>
#include "cProdukt.h"

using namespace std;

int main()
{
    cProdukt p1(1, "maslo", 5, "100g", 5.42);
    //p1.Wypelnij(); skonczyc do punktu 5, chyba nie trzeba dynamicznej alokacji
    p1.Pokaz();
    p1.setLP(5);
    p1.Pokaz();
    cout << p1.getLP() << endl;
    //cProdukt p2(1, "maslo", 5, "100g", 5.42);
    //p2.Pokaz();
    system("PAUSE");
    return 0;
}
