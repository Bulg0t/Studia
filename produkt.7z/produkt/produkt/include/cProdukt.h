#ifndef CPRODUKT_H
#define CPRODUKT_H
#include <string>
using namespace std;

class cProdukt
{
    public:
        cProdukt();
        cProdukt(int Nlp, string Nnazwa, double Nilosc, string Nunit, double Ncena);
        ~cProdukt();
        void Wypelnij(); // uzupelnianie danych o produkcie
        void Pokaz(); // wyswietlanie danych o produkcie
        void setLP(int);
        int getLP(void);
    protected:

    private:
        int lp; // jezeli chcemy zmienic liczbe porzadkowa tworzymy metode setLP pobiera int  i getLP zwraca int (settery i gettery)
        string nazwa; //nazwa produktu
        double ilosc; // ilosc danego produktu
        string unit; // jednostka miary, np 5kg, 10 sztuk
        double cena; // cena
        double vat; // wartosc podatku VAT

};

#endif // CPRODUKT_H
